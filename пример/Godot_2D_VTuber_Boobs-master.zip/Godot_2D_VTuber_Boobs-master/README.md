# 2D Boob Jiggle Physics (with a vertex shader)

Just tried making 2D jiggle physics using a vertex shader

## YouTube video (includes code explanation)

[![Watch the video](https://img.youtube.com/vi/mm6VDGPa0F0/maxresdefault.jpg)](https://youtu.be/mm6VDGPa0F0)

## My Socials

<p align="center">
	<a href="https://www.youtube.com/channel/UCD7K_FECPHTF0z5okAVlh0g/featured" target="blank"><img src="https://img.shields.io/badge/NekotoArts-%23FF0000.svg?style=for-the-badge&logo=YouTube&logoColor=white" alt="NekotoArts" /></a>
	<a href="https://twitter.com/NekotoArts" target="blank"><img src="https://img.shields.io/badge/NekotoArts-%231DA1F2.svg?style=for-the-badge&logo=Twitter&logoColor=white" alt="NekotoArts" /></a>
	<a href="https://nekotoarts.itch.io/" target="blank"><img src="https://img.shields.io/badge/Itch-%23FF0B34.svg?style=for-the-badge&logo=Itch.io&logoColor=white" /></a>
	<a href="https://ko-fi.com/nekoto" target="blank"><img src="https://img.shields.io/badge/Ko--fi-F16061?style=for-the-badge&logo=ko-fi&logoColor=white" /></a>
	<a href="https://godotshaders.com/author/nekotoarts/" target="blank"><img src="https://img.shields.io/badge/Godot_Shaders-%23FFFFFF.svg?style=for-the-badge&logo=godot-engine" /></a>
	<a href="https://reddit.com/user/XDGregory" target="blank"><img src="https://img.shields.io/badge/Reddit-FF4500?style=for-the-badge&logo=reddit&logoColor=white" /></a>
</p>

If you like my stuff, consider a sub to my [channel](https://www.youtube.com/channel/UCD7K_FECPHTF0z5okAVlh0g)?
